// expose module classes

exports.intersect = require('./lib/intersect');
exports.shape = require('./lib/IntersectionParams').newShape;