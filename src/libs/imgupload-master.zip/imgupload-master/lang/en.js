CKEDITOR.plugins.setLang('imgupload', 'en', {
    uploading: ' image(s) are uploading...',
    failToUpload: 'Failed to upload:',
    uploadImages: 'Upload images',
    validationFail: 'Only JPG, PNG, GIF and BMP allowed'
});
